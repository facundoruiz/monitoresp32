#!/bin/sh

cd .. && doxygen doxygen.cfg -w html

